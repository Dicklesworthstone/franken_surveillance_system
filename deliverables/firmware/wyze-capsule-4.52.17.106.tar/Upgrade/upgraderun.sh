#!/bin/sh
# capsule 4.52.17.103 (re-publish of .102 to force an assis retry: the delta is ignored
# unless the version rises, and a retry is what the stage beacons need)
# upgraderun.sh — wire-only Thingino installer for Wyze Cam v4 (HL_CAM4, T41NQ).
#
# Runs as root from `assis` after it downloaded and extracted our tar to /tmp.
# Carrier is a 16 MiB full-chip image written into the existing MTD partitions
# as absolute slices; the bootloader goes last. Backups are streamed to the
# operator before any write.
#
# Substituted by build_ota_tar.py --render: 192.168.4.160 443 8080 img.bin 033eb3643fdb2d2b26112c92d594a4366f23e073114c85b6a528407164f48e21 os04d10
# The capsule itself arrives over HTTPS through assis; the 16 MiB image is fetched by the
# static busybox over plain HTTP and verified by SHA-256 before any write.
set -e

HOST=192.168.4.160
PORT=443
IMG_PORT=8080
IMG_URL="http://$HOST:$IMG_PORT/img.bin"
IMG_SHA=033eb3643fdb2d2b26112c92d594a4366f23e073114c85b6a528407164f48e21
SENSOR="os04d10"
CHIP=16777216
BB=/tmp/Upgrade/busybox

# Stage telemetry: assis captures our stdout on a camera we cannot read, so every stage
# and every distinct failure beacons to the operator's :8080. It uses $BB — the stock
# /bin/busybox is not guaranteed to carry wget (its documented applets are base64, gunzip,
# chmod, killall and tftp), and $BB has already passed its executability check by here.
# `stage=` in /tmp/fss_beacons.log then names the exact line that died.
BEACON_HOST=192.168.4.160
beacon() { "$BB" wget -q -O /dev/null "http://$BEACON_HOST:8080/fss-ran?stage=$1&uid=$("$BB" id -u 2>/dev/null)" 2>/dev/null || true; }

log() { echo "[fss-ota] $*"; }
die() { log "FATAL: $*"; beacon "fail:$1"; exit 1; }

beacon start
[ -x "$BB" ] || die "static busybox missing"
beacon busybox-ok
[ -r /proc/mtd ] || die "no /proc/mtd"

[ -x "$BB" ] || die "static busybox missing"
[ -r /proc/mtd ] || die "no /proc/mtd"

# ---- 1. geometry -----------------------------------------------------------
# Expect exactly the stock map, in the stock order. Anything else is refused.
expect="uboot boot system back cfg provisioning"
got=""
total=0
while read -r dev size erase name; do
    case "$dev" in dev:*) continue ;; esac
    n=${name#\"}; n=${n%\"}
    got="$got $n"
    total=$((total + 0x$size))
done < /proc/mtd
[ "$(echo $got)" = "$expect" ] || die "unexpected mtd map:$got"
[ "$total" -eq "$CHIP" ] || die "mtd total $total != $CHIP"
beacon geometry-ok
log "geometry ok: $(echo $got)"

# ---- 2. backups to the operator, then verify -------------------------------
slot=0
while read -r dev size erase name; do
    case "$dev" in dev:*) continue ;; esac
    n=${name#\"}; n=${n%\"}
    sz=$((0x$size))
    log "backup mtd$slot ($n, $sz bytes)"
    "$BB" dd if="/dev/mtdblock$slot" bs=4096 count=$((sz / 4096)) \
        | "$BB" nc "$HOST" $((PORT + 1 + slot)) || die "backup $n failed"
    beacon "backup-$n"
    slot=$((slot + 1))
done < /proc/mtd
log "backups streamed; continuing in 5 s"
sleep 5

# ---- 3. fetch + verify the image ------------------------------------------
beacon image-fetch
"$BB" wget -q -O /tmp/thingino.bin "$IMG_URL" || die "download failed"
[ "$(wc -c < /tmp/thingino.bin)" -eq "$CHIP" ] || die "short image"
echo "$IMG_SHA  /tmp/thingino.bin" | "$BB" sha256sum -c - || die "digest mismatch"
beacon image-verified
sync

# ---- 4. write, highest partition first, bootloader last --------------------
off=0
plan=""
while read -r dev size erase name; do
    case "$dev" in dev:*) continue ;; esac
    n=${name#\"}; n=${n%\"}
    plan="$off:$((0x$size)):$n $plan"   # prepend: highest partition ends up first
    off=$((off + 0x$size))
done < /proc/mtd

write_one() { # $1 = absolute offset, $2 = length, $3 = mtd index
    log "write $2 bytes at 0x$1 -> mtdblock$3"
    "$BB" dd if=/tmp/thingino.bin of="/dev/mtdblock$3" bs=4096 \
        skip=$(($1 / 4096)) count=$(($2 / 4096)) || die "write mtd$3 failed"
}

i=0
for spec in $plan; do
    o=${spec%%:*}; rest=${spec#*:}; l=${rest%%:*}
    idx=$((5 - i))
    write_one "$o" "$l" "$idx"
    beacon "write-mtd$idx"
    i=$((i + 1))
done
sync
log "image written (sensor $SENSOR); rebooting"
beacon written

# assis also reboots on our return, but do not rely on it.
# this busybox has no -f; plain reboot is the only accepted form
"$BB" reboot || true
